package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class IdOverlapCheckProService {

	//아이디 중복 확인 Service
	public boolean isIdOverlapChk(String id) {
		boolean isIdOverlapChk = false;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			isIdOverlapChk = loginDAO.isIdOverlapChk(id);
		} catch (Exception e) {
			System.out.println("isIdOverlapChkService 에러" + e);
		} finally {
			close(con);
		}
		return isIdOverlapChk;
	}
}
