package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class ChangePwMemberChkService {

	//비밀번호 변경 전 회원구분 체크 Service
	public String isChangePwMemberCategory(String id, String originPw) {
		String isMemberCategory = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			isMemberCategory = loginDAO.isChangePwMemberCategory(id, originPw);
		} catch (Exception e) {
			System.out.println("isMemberCategoryService 에러" + e);
		} finally {
			close(con);
		}
		return isMemberCategory;
	}

	//비밀번호 변경 전 회원구분 체크 Service
	public String isChangePwMemberCategory(String id) {
		String isMemberCategory = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			isMemberCategory = loginDAO.isChangePwMemberCategory(id);
		} catch (Exception e) {
			System.out.println("isMemberCategoryService 에러" + e);
		} finally {
			close(con);
		}
		return isMemberCategory;
	}
	
}
