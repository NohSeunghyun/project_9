package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import vo.ActionForward;

public class CampaignInsertAdminGradeChkProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (admin_grade.equalsIgnoreCase("C")) {
			out.println("<script>");
			out.println("alert('등록할 권한이 없습니다.\\nA등급,B등급만 캠페인 등록 가능합니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("campaignInsertForm.page", false);
		}
		return forward;
	}

}
