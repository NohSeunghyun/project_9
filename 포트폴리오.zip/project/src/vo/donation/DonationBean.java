package vo.donation;

import java.sql.Date;

public class DonationBean {
	private int donation_no;
	private String donation_member_id;
	private String donation_money;
	private Date donation_date;
	private int donation_campaign_no;
	private String donation_type;
	private String pay_type;
	private String pay_status;
	
	public int getDonation_no() {
		return donation_no;
	}
	public void setDonation_no(int donation_no) {
		this.donation_no = donation_no;
	}
	public String getDonation_member_id() {
		return donation_member_id;
	}
	public void setDonation_member_id(String donation_member_id) {
		this.donation_member_id = donation_member_id;
	}
	public Date getDonation_date() {
		return donation_date;
	}
	public void setDonation_date(Date donation_date) {
		this.donation_date = donation_date;
	}
	public int getDonation_campaign_no() {
		return donation_campaign_no;
	}
	public void setDonation_campaign_no(int donation_campaign_no) {
		this.donation_campaign_no = donation_campaign_no;
	}
	public String getDonation_type() {
		return donation_type;
	}
	public void setDonation_type(String donation_type) {
		this.donation_type = donation_type;
	}
	public String getPay_type() {
		return pay_type;
	}
	public void setPay_type(String pay_type) {
		this.pay_type = pay_type;
	}
	public String getPay_status() {
		return pay_status;
	}
	public void setPay_status(String pay_status) {
		this.pay_status = pay_status;
	}
	public String getDonation_money() {
		return donation_money;
	}
	public void setDonation_money(String donation_money) {
		this.donation_money = donation_money;
	}
	
}