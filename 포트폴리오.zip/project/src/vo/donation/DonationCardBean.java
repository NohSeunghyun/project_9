package vo.donation;

public class DonationCardBean {
	private int donation_no;
	private String card_category;
	private String card_proprietor;
	private String pay_date;
	
	public int getDonation_no() {
		return donation_no;
	}
	public void setDonation_no(int donation_no) {
		this.donation_no = donation_no;
	}
	public String getCard_proprietor() {
		return card_proprietor;
	}
	public void setCard_proprietor(String card_proprietor) {
		this.card_proprietor = card_proprietor;
	}
	public String getPay_date() {
		return pay_date;
	}
	public void setPay_date(String pay_date) {
		this.pay_date = pay_date;
	}
	public String getCard_category() {
		return card_category;
	}
	public void setCard_category(String card_category) {
		this.card_category = card_category;
	}
	
}
