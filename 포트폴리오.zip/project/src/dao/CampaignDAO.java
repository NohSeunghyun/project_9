package dao;

import static db.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vo.campaign.CampaignBean;
import vo.campaign.CampaignListBean;

public class CampaignDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	private static CampaignDAO campaignDAO;

	public static CampaignDAO getInstance() {
		if (campaignDAO == null) {
			campaignDAO = new CampaignDAO();
		}
		return campaignDAO;
	}

	public void setConnection(Connection con) {
		this.con = con;
	}

	//모든 캠페인 조회
	public ArrayList<CampaignBean> getCampaign() {
		ArrayList<CampaignBean> campaignList = new ArrayList<CampaignBean>();
		try {
			sql = "select campaign_no, campaign_name, campaign_content,campaign_file, balance, format(amount,0) as amount, format(campaign_all_fund_raised,0) as campaign_all_fund_raised from campaign_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			CampaignBean campaign = null;
			
			while (rs.next()) {
				campaign = new CampaignBean();
				
				campaign.setCampaign_no(rs.getInt("campaign_no"));
				campaign.setCampaign_name(rs.getString("campaign_name"));
				campaign.setCampaign_content(rs.getString("campaign_content"));
				campaign.setCampaign_all_fund_raised(rs.getString("campaign_all_fund_raised"));
				campaign.setBalance(rs.getString("balance"));
				campaign.setAmount(rs.getString("amount"));
				campaign.setCampaign_file(rs.getString("campaign_file"));
				
				campaignList.add(campaign);
			}
		} catch (Exception e) {
			System.out.println("getCampaign 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return campaignList;
	}

	//캠페인 등록
	public int campaignInsert(CampaignBean campaignBean) {
		int insertCount = 0;
		try {
			sql = "insert into campaign_tbl(campaign_name, campaign_content, campaign_all_fund_raised, balance, amount, campaign_file) values(?, ?, '0', '0', '0', ?)";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setString(1, campaignBean.getCampaign_name());
			pstmt.setString(2, campaignBean.getCampaign_content());
			pstmt.setString(3, campaignBean.getCampaign_file());
			
			insertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("campaignInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return insertCount;
	}

	//캠페인 삭제
	public int campaignDelete(int campaign_no) {
		int deleteCount = 0;
		try {
			sql = "delete from campaign_tbl where campaign_no = " + campaign_no;
			pstmt = con.prepareStatement(sql);
			
			deleteCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("campaignDelete 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return deleteCount;
	}

	//캠페인 수정 전 정보조회
	public CampaignBean getCampaignInfo(int campaign_no) {
		CampaignBean campaignInfo = null;
		try {
			sql = "select campaign_no, campaign_name, campaign_content,campaign_file, format(campaign_all_fund_raised,0) as campaign_all_fund_raised, format(balance, 0) as balance, format(amount, 0) as amount  from campaign_tbl where campaign_no = " + campaign_no;
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				campaignInfo = new CampaignBean();
				
				campaignInfo.setCampaign_no(rs.getInt("campaign_no"));
				campaignInfo.setCampaign_name(rs.getString("campaign_name"));
				campaignInfo.setCampaign_content(rs.getString("campaign_content"));
				campaignInfo.setCampaign_all_fund_raised(rs.getString("campaign_all_fund_raised"));
				campaignInfo.setBalance(rs.getString("balance"));
				campaignInfo.setAmount(rs.getString("amount"));
				campaignInfo.setCampaign_file(rs.getString("campaign_file"));
			}
		} catch (Exception e) {
			System.out.println("getCampaignInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return campaignInfo;
	}

	//캠페인 수정(사진)
	public int campaignUpdateChangeImage(CampaignBean campaignBean) {
		int UpdateCount = 0;
		try {
			sql = "update campaign_tbl set campaign_file = '" + campaignBean.getCampaign_file() + "' where campaign_no = " + campaignBean.getCampaign_no();
			pstmt = con.prepareStatement(sql);
			
			UpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("campaignUpdateIncludeFile 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return UpdateCount;
	}

	//캠페인 수정(제목, 내용)
	public int campaignUpdate(String campaign_name, String campaign_content, int campaign_no) {
		int UpdateCount = 0;
		try {
			sql = "update campaign_tbl set campaign_name = '" + campaign_name + "', campaign_content = '" + campaign_content + "' where campaign_no = " + campaign_no;
			pstmt = con.prepareStatement(sql);
			
			UpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("campaignUpdate 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return UpdateCount;
	}

	//캠페인 지원 단체 목록 조회
	public ArrayList<CampaignListBean> getCampaignDetailList(int campaign_no) {
		ArrayList<CampaignListBean> campaignDetailList = new ArrayList<CampaignListBean>();
		try {
			sql = "select group_no, campaign_list_group, campaign_list_group_intro, format(campaign_list_amount, 0) as campaign_list_amount from campaign_tbl join campaign_list_tbl on campaign_no = " + campaign_no + " and campaign_no = campaign_list_no and group_status = 'Y'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			CampaignListBean campaignList = null;
			
			while (rs.next()) {
				campaignList = new CampaignListBean();
				
				campaignList.setGroup_no(rs.getInt("group_no"));
				campaignList.setCampaign_list_no(campaign_no);
				campaignList.setCampaign_list_group(rs.getString("campaign_list_group"));
				campaignList.setCampaign_list_group_intro(rs.getString("campaign_list_group_intro"));
				campaignList.setCampaign_list_amount(rs.getString("campaign_list_amount"));
				
				campaignDetailList.add(campaignList);
			}
		} catch (Exception e) {
			System.out.println("getCampaign 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return campaignDetailList;
	}

	//캠페인 지원 단체 수정 전 정보조회
	public CampaignListBean getCampaignDetailInfo(int group_no) {
		CampaignListBean campaignDetailInfo = null;
		try {
			sql = "select * from campaign_list_tbl where group_no = " + group_no ;
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				campaignDetailInfo = new CampaignListBean();
				
				campaignDetailInfo.setGroup_no(group_no);
				campaignDetailInfo.setCampaign_list_no(rs.getInt("campaign_list_no"));
				campaignDetailInfo.setCampaign_list_group(rs.getString("campaign_list_group"));
				campaignDetailInfo.setCampaign_list_group_intro(rs.getString("campaign_list_group_intro"));
				campaignDetailInfo.setCampaign_list_amount(rs.getString("campaign_list_amount"));
			}
		} catch (Exception e) {
			System.out.println("getCampaignDetailInfo 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return campaignDetailInfo;
	}

	//캠페인 지원 단체 수정
	public int supportUpdate(int group_no, String group_name, String group_intro) {
		int UpdateCount = 0;
		try {
			sql = "update campaign_list_tbl set campaign_list_group = '" + group_name + "', campaign_list_group_intro = '" + group_intro + "' where group_no = " + group_no;
			pstmt = con.prepareStatement(sql);
			
			UpdateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("supportUpdate 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return UpdateCount;
	}

	//캠페인 지원 단체 삭제
	public int supportGroupDelete(int group_no) {
		int deleteCount = 0;
		try {
			sql = "delete from campaign_list_tbl where group_no = " + group_no;
			pstmt = con.prepareStatement(sql);
			
			deleteCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("supportGroupDelete 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return deleteCount;
	}

	//캠페인 지원 단체 추가
	public int supportInsert(CampaignListBean supportBean) {
		int insertCount = 0;
		try {
			sql = "insert into campaign_list_tbl(campaign_list_no, campaign_list_group, campaign_list_group_intro, campaign_list_amount) values(?, ?, ?, '0')";
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1, supportBean.getCampaign_list_no());
			pstmt.setString(2, supportBean.getCampaign_list_group());
			pstmt.setString(3, supportBean.getCampaign_list_group_intro());
			
			insertCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("campaignInsert 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return insertCount;
	}

	//지원금 전송 전 캠페인 후원금 잔액 확인 
	public long getBalance(int campaign_no) {
		long balance = 0;
		try {
			sql = "select balance from campaign_tbl where campaign_no = " + campaign_no;
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				balance = Long.parseLong(rs.getString("balance"));
			}
		} catch (Exception e) {
			System.out.println("getBalance 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return balance;
	}

	//잔액 콤마찍기
	public String getBalanceFormat(int campaign_no) {
		String balance = "";
		try {
			sql = "select format(balance, 0) as balance from campaign_tbl where campaign_no = " + campaign_no;
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				balance = rs.getString("balance");
			}
		} catch (Exception e) {
			System.out.println("getBalanceFormat 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return balance;
	}

	//지원금 전송 후 캠페인 잔액, 보낸 지원금 수정
	public int grantSendCampaignInfoUpdate(int campaign_no, long amount) {
		int updateCount = 0;
		try {
			sql = "update campaign_tbl set balance = cast(balance as unsigned) - ? , amount = cast(amount as unsigned) + ? where campaign_no = " + campaign_no;
			pstmt = con.prepareStatement(sql);
			
			pstmt.setLong(1, amount);
			pstmt.setLong(2, amount);
			
			updateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("grantSendCampaignInfoUpdate 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return updateCount;
	}

	//지원금 전송 후 지원단체 지원금 수정
	public int grantSendSupportGroupInfoUpdate(int group_no, long amount) {
		int updateCount = 0;
		try {
			sql = "update campaign_list_tbl set campaign_list_amount = cast(campaign_list_amount as unsigned) + ? where group_no = " + group_no;
			pstmt = con.prepareStatement(sql);
			
			pstmt.setLong(1, amount);
			
			updateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("grantSendSupportGroupInfoUpdate 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return updateCount;
	}

	//모든 캠페인 지원단체 목록 조회
	public ArrayList<CampaignListBean> getSupportGroup() {
		ArrayList<CampaignListBean> supportGroupList = new ArrayList<CampaignListBean>();
		try {
			sql = "select group_no, campaign_list_no, campaign_list_group, campaign_list_group_intro, format(campaign_list_amount, 0) as campaign_list_amount from campaign_list_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			CampaignListBean supportGroup = null;
			
			while (rs.next()) {
				supportGroup = new CampaignListBean();
				
				supportGroup.setGroup_no(rs.getInt("group_no"));
				supportGroup.setCampaign_list_no(rs.getInt("campaign_list_no"));
				supportGroup.setCampaign_list_group(rs.getString("campaign_list_group"));
				supportGroup.setCampaign_list_group_intro(rs.getString("campaign_list_group_intro"));
				supportGroup.setCampaign_list_amount(rs.getString("campaign_list_amount"));
				
				supportGroupList.add(supportGroup);
			}
		} catch (Exception e) {
			System.out.println("getSupportGroup 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return supportGroupList;
	}

	//기부 시 캠페인 후원금 업데이트
	public int campaignUpdateAllFundRaised(int campaign_no, long donation_money1) {
		int updateCount = 0;
		try {
			sql = "update campaign_tbl set balance = cast(balance as unsigned) + ?, campaign_all_fund_raised = cast(campaign_all_fund_raised as unsigned) + ? where campaign_no = " + campaign_no;
			pstmt = con.prepareStatement(sql);
			
			pstmt.setLong(1, donation_money1);
			pstmt.setLong(2, donation_money1);
			
			updateCount = pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println("campaignUpdateAllFundRaised 에러 : " + e);
		} finally {
			close(pstmt);
		}
		return updateCount;
	}

	//기업/단체회원 구분
	public String getComgrpCategory(String id) {
		String member_groupChk = "";
		try {
			sql = "select comgrp_member_category from comgrp_member_tbl where comgrp_member_id = '" + id + "'";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				if (rs.getString("comgrp_member_category").equalsIgnoreCase("G")) {
					member_groupChk = "group";
				}
			}
		} catch (Exception e) {
			System.out.println("getComgrpCategory 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return member_groupChk;
	}
	
}
