drop table comgrpMember_donation_bankInfo_tbl;
drop table comgrpMember_donation_cardInfo_tbl;
drop table normalMember_donation_bankInfo_tbl;
drop table normalMember_donation_cardInfo_tbl;
drop table comgrpMember_donation_tbl;
drop table normalMember_donation_tbl;
drop table campaign_history_tbl;
drop table campaign_list_tbl;
drop table campaign_tbl;
drop table admin_tbl;
drop table comgrp_member_tbl;
drop table normal_member_tbl;
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table normal_member_tbl(
normal_member_id varchar(30) not null primary key,
normal_member_pw varchar(30) not null,
normal_member_name varchar(30) not null,
normal_member_birth varchar(10) not null,
normal_member_phone varchar(15) not null,
normal_member_gender varchar(1) not null,
normal_member_email varchar(50),
normal_member_date date not null,
normal_member_grade varchar(3) not null default 'C'
);

insert into normal_member_tbl values('nsh11111', 'nsh11111', '노', '1993-09-27', '010-0000-0000', 'M', 'tatsos93@Nate.com', now(), default);
insert into normal_member_tbl values('jjh11111', 'jjh11111', '주', '1991-05-01', '010-0000-0001', 'M', 'abc@Naver.com', now(), default);
insert into normal_member_tbl values('kmj11111', 'kmj11111', '김', '1990-11-15', '010-0000-0002', 'M', 'def@Nate.com', now(), default);

select * from normal_member_tbl;

create table comgrp_member_tbl(
comgrp_member_id varchar(30) not null primary key,
comgrp_member_pw varchar(30) not null,
comgrp_member_category varchar(1) not null,
comgrp_member_name varchar(30) not null,
comgrp_manager_name varchar(30) not null,
comgrp_member_companyno varchar(12) not null,
comgrp_manager_phone varchar(15) not null,
comgrp_member_email varchar(50),
comgrp_member_date date not null,
comgrp_member_grade varchar(3) not null default 'C'
);

insert into comgrp_member_tbl values ('com11111', 'com11111', 'C', '기업1', '기업관리자1', '기업사업자번호1', '010-1000-0000', 'com1@Nate.com', now(), default);
insert into comgrp_member_tbl values ('grp11111', 'grp11111', 'G', '단체1', '단체관리자1', '단체사업자번호1', '010-2000-0000', 'grp1@Nate.com', now(), default);
insert into comgrp_member_tbl values ('com22222', 'com22222', 'C', '기업2', '기업관리자2', '기업사업자번호2', '010-1000-0001', 'com2@Nate.com', now(), default);
insert into comgrp_member_tbl values ('grp22222', 'grp22222', 'G', '단체2', '단체관리자2', '단체사업자번호2', '010-2000-0001', 'grp2@Nate.com', now(), default);

select * from comgrp_member_tbl;

create table admin_tbl(
admin_id varchar(30) not null primary key,
admin_pw varchar(30) not null,
admin_name varchar(30) not null,
admin_phone varchar(15) not null,
admin_date date not null,
admin_grade varchar(3) not null default 'C'
);

insert into admin_tbl values ('nsh00000', 'nsh00000', '노승현', '010-8883-1564', now(), 'A');
insert into admin_tbl values ('jjh00000', 'jjh00000', '주종환', '010-0000-0000', now(), 'B');
insert into admin_tbl values ('kmj00000', 'kmj00000', '김무준', '010-1111-1111', now(), 'C');

select * from admin_tbl;

create table campaign_tbl(
campaign_no int auto_increment not null primary key,
campaign_name varchar(30) not null,
campaign_content nvarchar(2000) not null,
campaign_all_fund_raised varchar(20) not null,
balance varchar(20) not null,
amount varchar(20) not null,
campaign_file nvarchar(50) not null
);

insert into campaign_tbl(campaign_name,campaign_content,campaign_all_fund_raised, balance, amount, campaign_file) values ('결손아동 지원캠페인', '결손아동 지원하는 단체에 후원금을 보냅니다.', '0', '0', '0', 'ed01c3894c413.jpg');
insert into campaign_tbl(campaign_name,campaign_content,campaign_all_fund_raised, balance, amount, campaign_file) values ('한부모자녀 지원캠페인', '한부모자녀 지원하는 단체에 후원금을 보냅니다.', '0', '0', '0', 'maxresdefault.jpg');

select * from campaign_tbl;

create table campaign_list_tbl(
group_no int auto_increment not null primary key,
campaign_list_no int not null,
campaign_list_group varchar(30) not null,
campaign_list_group_intro nvarchar(2000) not null,
campaign_list_amount varchar(20) not null,
group_status varchar(1) not null,

constraint campaign_list_fk foreign key(campaign_list_no)
references campaign_tbl(campaign_no)
);

insert into campaign_list_tbl(campaign_list_no, campaign_list_group, campaign_list_group_intro, campaign_list_amount, group_status) values (1, '초록우산', '초록우산제단입니다.', '0', 'Y');
insert into campaign_list_tbl(campaign_list_no, campaign_list_group, campaign_list_group_intro, campaign_list_amount, group_status) values (1, '빨강우산', '빨강우산제단입니다.', '0', 'Y');
insert into campaign_list_tbl(campaign_list_no, campaign_list_group, campaign_list_group_intro, campaign_list_amount, group_status) values (2, '노랑우산', '노랑우산제단입니다.', '0', 'Y');
insert into campaign_list_tbl(campaign_list_no, campaign_list_group, campaign_list_group_intro, campaign_list_amount, group_status) values (2, '파랑우산', '파랑우산제단입니다.', '0', 'Y');

select * from campaign_list_tbl;

create table campaign_history_tbl(
campaign_support_campaign_name varchar(30) not null,
campaign_support_amount int not null,
campaign_support_group_name varchar(30) not null,
campaign_support_date date not null
);

select * from campaign_history_tbl;

create table normalMember_donation_tbl(
donation_no int auto_increment not null primary key,
donation_member_id varchar(30) not null,
donation_money varchar(20) not null,
donation_date date not null,
donation_campaign_no int not null,
donation_type varchar(1) not null,
pay_type varchar(1) not null,
pay_status varchar(1) not null,

constraint normal_member_donation_fk foreign key(donation_member_id)
references normal_member_tbl(normal_member_id),
constraint campaign_no_donation_fk foreign key(donation_campaign_no)
references campaign_tbl(campaign_no)
);

select * from normalMember_donation_tbl;

create table comgrpMember_donation_tbl(
donation_no int auto_increment not null primary key,
donation_member_id varchar(30) not null,
donation_money varchar(20) not null,
donation_date date not null,
donation_campaign_no int not null,
donation_type varchar(1) not null,
pay_type varchar(1) not null,
pay_status varchar(1) not null,

constraint comgrp_member_donation_fk foreign key(donation_member_id)
references comgrp_member_tbl(comgrp_member_id),
constraint campaign_no_donation_fk1 foreign key(donation_campaign_no)
references campaign_tbl(campaign_no)
);

select campaign_name
from campaign_tbl

select * from normalMember_donation_tbl
select * from comgrpMember_donation_tbl

select donation_campaign_no, donation_member_id, format(sum(donation_money),0) as donation_money from normalMember_donation_tbl where pay_status = 'y' group by donation_member_id, donation_campaign_no
select donation_campaign_no, donation_member_id, format(sum(donation_money),0) as donation_money from comgrpMember_donation_tbl where pay_status = 'y' group by donation_member_id, donation_campaign_no

create table normalMember_donation_cardInfo_tbl(
donation_no int not null primary key,
card_category varchar(15) not null,
card_proprietor varchar(30) not null,
pay_date varchar(2),

constraint card_donation_no_fk foreign key(donation_no)
references normalMember_donation_tbl(donation_no)
);

select * from normalMember_donation_cardInfo_tbl

create table normalMember_donation_bankInfo_tbl(
donation_no int not null primary key,
bank_category varchar(15) not null,
bank_proprietor varchar(30) not null,
bank_name varchar(30) not null,
pay_date varchar(2),

constraint bank_donation_no_fk foreign key(donation_no)
references normalMember_donation_tbl(donation_no)
);

create table comgrpMember_donation_cardInfo_tbl(
donation_no int not null primary key,
card_category varchar(15) not null,
card_proprietor varchar(30) not null,
pay_date varchar(2),

constraint card_donation_no_fk1 foreign key(donation_no)
references comgrpMember_donation_tbl(donation_no)
);

create table comgrpMember_donation_bankInfo_tbl(
donation_no int not null primary key,
bank_category varchar(15) not null,
bank_proprietor varchar(30) not null,
bank_name varchar(30) not null,
pay_date varchar(2),

constraint bank_donation_no_fk1 foreign key(donation_no)
references comgrpMember_donation_tbl(donation_no)
);
